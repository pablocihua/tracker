import { InspiniaPage } from './app.po';

describe('inspinia App', function() {
  let page: InspiniaPage;

  beforeEach(() => {
    page = new InspiniaPage();
  });

});
