import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { User } from '../objects/user';
import { TokenService } from '../services/token.service';
import { API_URL } from '../constants/treck.constant';
//import JsonApiDataStore = require("jsonapi-datastore/dist");
import 'rxjs/add/operator/toPromise';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';


@Injectable()
export class UserService {
	
	private _user: User
	private userLoggedIn: Subject<User> = new Subject();
	private userDrawerStream: Subject<boolean> = new Subject();
	userLoggedIn$ = this.userLoggedIn.asObservable();
	userDrawerStream$ = this.userDrawerStream.asObservable();
	commerce_id: any;
	user_id: any;


	constructor(private http: Http, private tokenService: TokenService) {
		this._user = this.tokenService.user;
	}

	get user() {
		return this._user;
	}

	set user(user: User) {
		this._user = user;
	}
/////////////////////////////////////////////////////////////////////////





	login(user: User) : Promise<User> {

	let headers = new Headers({
			'Content-Type': 'application/json',
			'Authorization': 'Bearer ' + user.token	
		});

		return this.http
			.post(API_URL + 'clientes/auth', user,{ headers: headers })
			.toPromise()
			.then(res => {
				//let usuario = JSON.stringify(user);
				let token = res.json().token;
				let usuario = res.json();
					
			  	this.tokenService.user = usuario;
		
			  	let data = res.headers;

			console.log(data)
				return usuario;
			})
			.catch(this.handleError)
	}







	logout() {
		let user = new User();
		this.drawer(false);
		this.tokenService.reset();
		this.userLoggedIn.next(user);
	}
	  drawer(val) {
    	this.userDrawerStream.next(val);
    }
    handleError(error: any) {
		console.error('un error ocurrido', error);
		return Promise.reject(error.message || error);
	}


//////////////////////////////////////////////////////////////////////////

	create(user: User) : Promise<User> {
		

		return this.http
			.post(API_URL + 'clientes', user)
			.toPromise()
			.then(res => {
				 let usuario = res.json();
					
			  	this.tokenService.user = usuario;

				
				return usuario;
			})
	}


	update(user: User) : Promise<User> {

	let headers = new Headers({
	 'token': this._user.token,
	 'Content-Type': 'application/json'
     
		});


        return this.http
            .put(API_URL + 'clientes/' + this._user._id , user,{ headers: headers })
            .toPromise()
            .then(res => {
                let usuario = res.json();
					
			  	this.tokenService.user = usuario;
			  	console.log(usuario);
                return usuario;
            })
            .catch(this.handleError)
    }


///////////////////////////////////////////////////////////////////////////////

invited(user: User) : Promise<User> {

	let headers = new Headers({
	 'token': this._user.token,
	 'Content-Type': 'application/json'
     
		});

        return this.http
            .post(API_URL + 'clientes/' + this._user._id +'/invitado', user,{ headers: headers })
            .toPromise()
            .then(res => {
                let usuario = res.json();
					

                return usuario;
            })
            .catch(this.handleError)
    }


    ///////////////////////////////////INVITED LIST///////////////////////////////////////////

	invitedlist() : Promise<User> {

	let headers = new Headers({
	 'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6eyJpZF91c2VyIjoiNThiMzEyY2M5MmJiMmQzMzA3NWU5NWQxIn0sImlhdCI6MTQ4ODI5NzQ4OX0.UQZxCdzneHWGfGMRW0B1kUtbtRZuQIpZd1sIk_bJPrM',
	 'Content-Type': 'application/json'
     
		});

      return this.http
			.get(API_URL + 'clientes/' + this._user._id + '/invitados/all',{ headers: headers })
			.toPromise()
			.then(res => res.json())
			.catch(this.handleError)
	}

     ////////////////////////////////////DELETE INVITED//////////////////////////////////////////



	inviteddelete(id_usuario) : Promise<User> {

	let headers = new Headers({
	 'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6eyJpZF91c2VyIjoiNThiMzEyY2M5MmJiMmQzMzA3NWU5NWQxIn0sImlhdCI6MTQ4ODI5NzQ4OX0.UQZxCdzneHWGfGMRW0B1kUtbtRZuQIpZd1sIk_bJPrM',
	 'Content-Type': 'application/json'
     
		});

      return this.http
			.delete(API_URL + 'clientes/' + this._user._id + '/invitado/'+this._user.invitados[0],{ headers: headers })
			.toPromise()
			.then(res => res.json())
			.catch(this.handleError) 
	}







      //////////////////////////////////////////////////////////////////////////////

	/*
	forgotPassword(user: User) : Promise<Response> {
		return this.http
			.post(API_URL + '/users/forgot-password', JSON.stringify(user))
			.toPromise()
	}
	*/

/*
	create_with_calendar(data) : Promise<any> { 
		return this.http
			.post(API_URL + '/commerces/' + this.commerceService.commerce_id + '/calendar/schedule/new-user' , JSON.stringify(data))
			.toPromise()
			.then(res => {
				return res.json();
			})
			.catch(this.handleError)
	}
	
	changePassword(user: User) : Promise<User> {
		
		let headers = new Headers({
			'Content-Type': 'application/json',
			'Authorization': 'Bearer ' + user.token	
		});

		return this.http
			.post(API_URL + '/users/change-password', JSON.stringify(user), { headers: headers })
			.toPromise()
			.then(res => {
				let data = res.json().data;
				let user = data.attributes;
				user.id = data.id;
				this.tokenService.user = user;
				return user;
			})
			.catch(this.handleError)
	}

	commerces() : Promise<Commerce[]> {
		
		return this.http
			.get(API_URL + '/users/' + this._user.id + '/commerces')
			.toPromise()
			.then(res => res.json().data)
			.catch(this.handleError)
	}

	createCommerce(commerce: Commerce) : Promise<Commerce> {
		
		let data = {commerce: commerce}

		return this.http
			.post(API_URL + '/users/' + this._user.id + '/commerces/create', JSON.stringify(data))
			.toPromise()
			.then(res => { 
				let data = res.json().data;
				let commerce = data.attributes;
				commerce.id = data.id;
				return commerce;
			})
			.catch(this.handleError)
	}

	invite(user: User) : Promise<User> {
		return this.http
			.post(API_URL + '/commerces/' + this.commerceService.commerce_id + '/users/invite', JSON.stringify(user))
			.toPromise()
			.then(res => {
				return res.json().data
			})
			.catch(this.handleError);
	}
	
	

 
	CreateCommerceUser(user: User, commerce_id: string) : Promise<User> {
		
		let headers = new Headers({
			'Content-Type': 'application/json'
		});

		let data = {user: user}

		return this.http
			.post(API_URL + '/commerces/' + commerce_id + '/users/create', JSON.stringify(data), { headers: headers })
			.toPromise()
			.then(res => {
				let data = res.json().data;
				let user = data.attributes;
				user.id = data.id;
				this.tokenService.user = user;
				this._user = user;
				return user;
			});
	}



	join(commerce_id: string, user_id: string ) : Promise<any> { 
		return this.http
			.post(API_URL + '/commerces/' + commerce_id + '/users/'+ user_id + '/join' , JSON.stringify(user_id))
			.toPromise()
			.then(res => {
				return res.json();
			})
			.catch(this.handleError)
	}



    search(email) {
    	let options = new RequestOptions({
        	search: new URLSearchParams('email=' + email)
      	});

    	return this.http
    		.get(API_URL + '/users/search', options)
    		.map(res => {
    			let json = res.json();
    			let store = new JsonApiDataStore.JsonApiDataStore();
				store.sync(json);
				let data = store.find('users', json.data.id);
    			return data;
    		}).catch(() => Observable.of(null))
    }

    drawer(val) {
    	this.userDrawerStream.next(val);
    }

	handleError(error: any) {
		console.error('An error ocurr', error);
		return Promise.reject(error.message || error);
	}

	private handleErrorObservable (error: any) {
	    // In a real world app, we might use a remote logging infrastructure
	    // We'd also dig deeper into the error to get a better message
	    let errMsg = (error.message) ? error.message :
	      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
	    console.error(errMsg); // log to console instead
	    return Observable.throw(errMsg);
	  }*/
}