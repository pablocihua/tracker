import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators }  from '@angular/forms';



@Component({
	selector: 'verificacion',
	templateUrl: 'verificacion.template.html'
	})
export class verificacionComponent implements OnInit{ 



	constructor( ) {

	}


	ngOnInit() {

	

	}


	
}