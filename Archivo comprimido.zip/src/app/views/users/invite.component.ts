import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators }  from '@angular/forms';
import { JsonApiDatastoreConfig, JsonApiDatastore } from 'angular2-jsonapi';

import { UserService } from '../../services/user.service';
import { TokenService } from '../../services/token.service';
import { User } from '../../objects/user';
@Component({
	selector: 'invite',
	templateUrl: 'invite.template.html'
	})
export class inviteComponent implements OnInit{ 

	user: any = new User();
	formInvitado: FormGroup;
	submitted: boolean = false;
	unauthorized: boolean = false;
	datausuario: any;
	id_usuario: any;
	constructor( private formBuilder: FormBuilder, private userService: UserService, private router: Router, private tokenService: TokenService) {

	}


	ngOnInit() {
	this.invitedlist()	
	this.tokenService.user.nombre


		//this.userService.logout();

		this.formInvitado = this.formBuilder.group({
			nombre: ['', Validators.required],
			email: ['', Validators.required],
			telefono: ['', Validators.required],
			perfil: ['', Validators.required],
			nombre_comercial: ['', Validators.required],
			razon_social: ['', Validators.required],
			password: ['', Validators.required]
			});


	

		this.userService.invitedlist().then(datausuario => {
			this.datausuario = datausuario
		});
	



	}

	invited() {
		this.userService.invited(this.formInvitado.value).then(user => {
			console.log("////valor de invitados////")
			console.log(this.formInvitado.value)

			}).catch(res => {
				console.log("Error en algun campo")

				});
		}


		invitedlist() {
			this.userService.invitedlist().then(user => {
				
				console.log("lista de invitados/");
				console.log(user);
				}).catch(res => {
					console.log("Error en algun campo2")
					
					});
			}

		inviteddelete(id_usuario) {
		this.userService.inviteddelete(id_usuario).then(user => {
			}).catch(res => {
				console.log("Error en algun campo")
				
				});
		}

}


		
