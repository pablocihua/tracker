import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators }  from '@angular/forms';


import { UserService } from '../../services/user.service';
import { TokenService } from '../../services/token.service';
import { User } from '../../objects/user';
@Component({
	selector: 'user',
	templateUrl: 'user.template.html'
	})
export class userComponent implements OnInit{ 

	formUpdate: FormGroup;
	submitted: boolean = false;
	unauthorized: boolean = false;
	user: any = this.tokenService.user;
	constructor( private formBuilder: FormBuilder, private userService: UserService, private router: Router, private tokenService: TokenService) {

	}


	ngOnInit() {
		console.log(this.user);
	this.tokenService.user.nombre
		//this.userService.logout();

		this.formUpdate = this.formBuilder.group({
			nombre: ['', Validators.required],
			email: ['', Validators.required],
			telefono: ['', Validators.required],
			tipo: ['', Validators.required],
			nombre_comercial: ['', Validators.required],
			razon_social: ['', Validators.required],
			password: ['', Validators.required]
			});


	}

	update() {
		this.userService.update(this.formUpdate.value).then(user => {
				}).catch(res => {
					console.log("Error en algun campo")
					
					});
			}
}