export const API_URL: string = 'http://treck.mx/app/api/v1/';
