export class User {
	_id: number;
	nombre: string;
	email: string;
	password: string;
	token: string;
	invitados: string;
	//constructor() {
	//	this.valid = true;
	//}
}
